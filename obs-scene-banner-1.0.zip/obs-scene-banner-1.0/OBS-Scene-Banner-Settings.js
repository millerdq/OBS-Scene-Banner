// ================ custom settings for OBS-Scene-Banner ================================
//Connection: must match OBS->Tools->Websockets Server Settings
WEBSOCKET_IP='localhost'; 	//Websockets server--use 'localhost' unless connecting remotely
WEBSOCKET_PORT='4444';		//Websockets server port
PASSWORD ='';     	      //Websockets password

PREFERRED_PROFILE=false; 		//prompt for any other profile: false/profile

//Horizontal Alignment Settings 
LEFT_WIDTH='160px';  		//left zone width; 0 to hide, ~'162px' aligns with a narrow dock
PREVIEW_WIDTH='40%';	      //preview zone width; use % to accommodate resizing
CENTER_WIDTH='180px';		//center zone width; suggest ~'180px' for typical separation
PROGRAM_WIDTH='40%';		   //program zone width; use % to accommodate resizing
RIGHT_WIDTH='160px';		   //right zone width; 0 to hide, ~'162px' aligns with a narrow dock	

//optional buttons     	false/true: all default to false
PUSH_BUTTON=true;				 //enable the push button
TRAN_BUTTON=true;				 //enable the transition button
GOLIVE_BUTTON=true;			 //enable the go live button
//RECORD_BUTTON=true;		    //enable the record button
MENU_BUTTON=true;			//enable the menu button

//optional features	   false/true: all default to false  
PUSH_SCENE=false;			   //designate a push scene: false/true or scene name
PUSH_SCENE_TOGGLE=true;		//allow push scene to toggle
//HIDE_SCENE_BOXES=true;	   //suppress colored border around scene name
//HIDE_MENU=true;				   //hide the menu
//STICKY_MENU=true;			   //do not dismiss menu automatically

//Layout Aids				false/true: all default to false
//PANE_BORDERS=true;			   //expose pane borders: false/true or css color
//PANE_BACKGROUND=true;		   //add a background to banner panes: false/true or css color
//HIDE_MESSAGE_AREA=true;	  	 //hides the feedback area below the banner: false/true

//Diagnostic Feedback			false/true: all default to false
SHOW_NOTICES=true;			//reveal scene banner notices
//SHOW_REQUESTS=true;		   //reveal websockets request messages
//SHOW_REPLIES=true;			   //reveal websockets reply messages
//SHOW_EVENTS=true;			   //reveal websocket event messages
//SHOW_AS_TICKER=true; 	  	//show messages in single-line ticker
//LOG_MESSAGES=true;			   //log messages to the console

//Menu links
LINK.push ({'name':'Help','url':'obs-scene-banner-help.html'});



