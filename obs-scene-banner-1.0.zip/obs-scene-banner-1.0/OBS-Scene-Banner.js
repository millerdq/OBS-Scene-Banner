//establish defaults
const DEFAULT={};
DEFAULT.WEBSOCKET_IP='localhost';
DEFAULT.WEBSOCKET_PORT='4444';	
DEFAULT.PASSWORD=	'';

DEFAULT.LEFT_WIDTH='0px';		
DEFAULT.RIGHT_WIDTH='0px';
DEFAULT.PREVIEW_WIDTH='40%';
DEFAULT.PROGRAM_WIDTH='40%';
DEFAULT.CENTER_WIDTH='180px';

DEFAULT.TRAN_BUTTON=				false;
DEFAULT.GOLIVE_BUTTON=			false;
DEFAULT.RECORD_BUTTON=			false;
DEFAULT.PUSH_BUTTON=				false;
DEFAULT.MENU_BUTTON=				false;

DEFAULT.PREFERRED_PROFILE=	false;
DEFAULT.PUSH_SCENE=	'';
DEFAULT.PUSH_SCENE_TOGGLE=	false;
DEFAULT.HIDE_SCENE_BOXES=		false;
DEFAULT.HIDE_MENU=					false;
DEFAULT.STICKY_MENU=				false;

DEFAULT.HIDE_MESSAGE_AREA=	false;
DEFAULT.SHOW_NOTICES=				false;
DEFAULT.SHOW_REQUESTS=			false;
DEFAULT.SHOW_REPLIES=				false;
DEFAULT.SHOW_EVENTS=				false;
DEFAULT.SHOW_AS_TICKER=			false;
DEFAULT.LOG_MESSAGES=				false;
DEFAULT.PANE_BORDERS=				false;
DEFAULT.PANE_BACKGROUND=		false;

//merge settings with defaults
const set={};
for (let item in DEFAULT) {
	set[item]= (eval('typeof ' + item) === 'undefined')?DEFAULT[item]:eval(item);
}

//append menulinks to menu
if (typeof LINK === 'object') {
	let txt='';
	for (let i=0; i<LINK.length; i++) {
		let link='<button onclick=openWindow("' + LINK[i].url + '")>' + LINK[i].name +'</button>';
		txt+=link;
	}
	document.getElementById('menuCenter').innerHTML=txt;
}

//constants
const OBS_version='Scene Banner 1.0';
const OBS_author='Dennis Q Miller, CDMP';
const OBS_supportUrl='dennis@musefeed.net';
const OBS_messageLimit=100;   //limit message count
const OBS_helpPage='OBS-Scene-Banner-Help.html';
const OBS_settingsPage='OBS-Scene-Banner-Settings.html';
const OBS_settingsCmd='obs-scene-banner-settings.cmd';
const OBS_settingsFile='OBS-Scene-Banner-Settings.js';
let href=location.href;
const OBS_path=href.substring(0,href.lastIndexOf('/'));  //path to this page
const OBS_name=href.substring(href.lastIndexOf('/')+1);  //name of this page
const OBS_folder=OBS_path.substring(OBS_path.lastIndexOf('/')+1);

const OBS_notices=document.getElementById('messages');
const OBS_banner=document.getElementById('banner');
const OBS_menubar=document.getElementById('menubar');
const OBS_pushButton=document.getElementById('pushButton');
const OBS_tranButton=document.getElementById('tranButton');
const OBS_tranTop=document.getElementById('tranTop');
const OBS_menuPushButton=document.getElementById('menuPushButton');
const OBS_menuTranButton=document.getElementById('menuTranButton');

window.addEventListener('error', askToStop);
window.addEventListener('load', obs_connect);
window.addEventListener('unload', obs_disconnect);
document.getElementById('menuButton').addEventListener('click',doShowMenu);
document.getElementById('tranButton').addEventListener('click',doTransition);
document.getElementById('pushButton').addEventListener('click',doPush);
document.getElementById('recordButton').addEventListener('click',doRecord);
document.getElementById('goliveButton').addEventListener('click',doGoLive);
document.getElementById('endliveButton').addEventListener('click',doEndLive);
document.getElementById('menuRefresh').addEventListener('click',doRefresh);
document.getElementById('menuPushButton').addEventListener('contextmenu',doSetPush);
document.getElementById('menuPushButton').addEventListener('click',doPush);
document.getElementById('menuTranButton').addEventListener('click',doTransition)
document.getElementById('menuAbout').addEventListener('click',doShowAbout);
document.getElementById('menuSettings').addEventListener('click',doShowSettings);
document.getElementById('menuDismiss').addEventListener('click',doHideMenu);
document.getElementById('menuCenter').addEventListener('click',doHideMenu);
OBS_banner.addEventListener('contextmenu',doShowMenu);
OBS_pushButton.addEventListener('contextmenu',doSetPush);
if (!set.STICKY_MENU) { //hide menu after any click
	document.addEventListener('click',doHideMenu);
} 
//globals
var OBS_socket;
var OBS_profile;
var OBS_studioMode;
var OBS_programScene;
var OBS_previewScene;
var OBS_pushScene;
var OBS_pushButtonScene;
var OBS_inTransition;
var OBS_pushInProgress;
var OBS_pushedPreview;
var OBS_tranBackground;   
var OBS_pushBackground;
var OBS_activeTransition;
var OBS_currentTransition;
var OBS_currentDuration;

//Websocket request constants
const OBS_GetStudioModeStatus = 'GetStudioModeStatus';
const OBS_GetStreamingStatus = 'GetStreamingStatus';
const OBS_GetAuthRequired = 'GetAuthRequired';
const OBS_GetCurrentScene = 'GetCurrentScene';
const OBS_GetPreviewScene = 'GetPreviewScene'
const OBS_GetCurrentProfile = 'GetCurrentProfile';
const OBS_GetCurrentTransition = 'GetCurrentTransition';
const OBS_SetPreviewScene = 'SetPreviewScene';
const OBS_SetCurrentScene = 'SetCurrentScene';
const OBS_StartStreaming = "StartStreaming";
const OBS_StopStreaming = "StopStreaming";
const OBS_StartRecording = "StartRecording";
const OBS_StopRecording = "StopRecording";
const OBS_Sleep = 'Sleep';
const OBS_Authenticate = 'Authenticate';
const OBS_TransitionToProgram = 'TransitionToProgram';
const OBS_GetSceneTransitionOverride = 'GetSceneTransitionOverride';
const OBS_SetSceneTransitionOverride = 'SetSceneTransitionOverride';
const OBS_RemoveSceneTransitionOverride = 'RemoveSceneTransitionOverride';

function obs_connect() {
	applyFormatting();
	applyStreamingEffects({'streaming':false,'recording':false});  //fake status msg until connected
	if (!set.WEBSOCKET_IP) {
      let txt='Unable to obtain WEBSOCKET_IP from "OBS-scene-banner-settings.js"';
      if(askToStop(txt)) {return;}
	}
//instantiate a global connection with OBS and activate callback handlers
	let server = set.WEBSOCKET_IP+':'+set.WEBSOCKET_PORT;
	if (set.SHOW_NOTICES) {showNotice('Connecting to OBS ('+server+')');}
	OBS_socket = new WebSocket('ws://' + server); //wss: doesn't work, TLS unsupported
	OBS_socket.onerror = function (e) {onError(e)};
	OBS_socket.onmessage= function(e) {onMessage(e)}; 
	OBS_socket.onopen = function (e) {onOpen(e)};
}
function obs_disconnect() {
	OBS_socket.close();
}
function onOpen(e) {
//handle authentication when connection opens
	obsRequest (OBS_GetAuthRequired);
	return;
}
function onError(error) {
   let txt = 'WebSocket Connection To OBS Failed on ' + set.WEBSOCKET_IP +':'+set.WEBSOCKET_PORT;   
	if(askToStop(txt)) {return;}
}
function askToStop (msg, source ) {
	let txt=(typeof msg === 'object')?(msg['message']?msg['message']:''):(msg?msg:''); 
	txt +=(source?' ('+source+')':'');
	if (confirm(txt+'\n\nAllow "' + OBS_name + '" to continue?')) {return false;}
	OBS_banner.style.display='none';
	OBS_notices.style.display='block';
	set.SHOW_AS_TICKER = false;
	showNotice (txt);
	OBS_socket.close();
	showNotice (OBS_name + ' stopped. Right-Click to restart');
	return true
}

function obsReady(msg) {
	OBS_pushScene = set.PUSH_SCENE?set.PUSH_SCENE:OBS_previewScene; 
	setPushButtonScene(OBS_pushScene, 'settings');
	applyStreamingEffects(msg);
	if (set.PREFERRED_PROFILE && (set.PREFERRED_PROFILE !== OBS_profile)) {
		let txt ='WARNING: Not Using Preferred Profile';
		txt+= '\n   Now Using: "' + OBS_profile + '"';
		txt+= '\n   Preferred: "' + set.PREFERRED_PROFILE + '"';
		alert(txt);
	}	
}

function doRefresh (href) {
	if (typeof href !== 'undefined') {location.href=href;}
	location.reload(true);
}

function doShowSettings () {
	let myWindow=openWindow(OBS_settingsPage);
	return;
}
function doShowAbout (){
	let txt = OBS_version;
	txt += '\n   ' + OBS_author;
	txt += '\n   ' + OBS_supportUrl;
	alert(txt);
}
function openWindow(url) {
	let options='height=100,menubar=yes,toolbar=yes';
	let myWindow=window.open(url);
}
	
function doSetPush(e) {
	let scene = OBS_studioMode?OBS_previewScene:OBS_programScene;
	if (set.SHOW_NOTICES) {showNotice('SET PUSH to ' + scene);}
	if (typeof e === 'object') {// suppress right-click
		e.preventDefault();
		e.stopPropagation();
	}
	
	if (OBS_pushScene === scene) {
		OBS_pushButton.disabled=true;
		OBS_menuPushButton.disabled=true;
		return;
	} 

	prompt = (typeof e === 'string')?e+'\n':'';
	if (confirm(prompt+'Change Push Scene to "' + scene + '"?')) {
		OBS_pushScene=scene;
		setPushButtonScene(scene,'button');
	}
}

function doPush(scene) {
	scene=(typeof scene === 'text')?scene:OBS_pushButtonScene;
	if (OBS_inTransition ) {return;}  // avoid while in transition
	if (scene === OBS_programScene) {return;}  //just in case
	let txt = 'PUSH: "' + scene + '"--&gt;"' + OBS_programScene +'"';
	if (set.SHOW_NOTICES) {showNotice(txt);}
	OBS_pushInProgress = scene;
	OBS_pushedPreview=OBS_previewScene;
	obsRequest ({'request-type':OBS_SetCurrentScene,'scene-name':scene});
}	

function doHideMenu() {
	OBS_menubar.style.display='none';
}

function doShowMenu(e) {
	if (set.HIDE_MENU) {return;}
	e.preventDefault();
	e.stopPropagation();
	OBS_menubar.style.display='flex';
}

function applyFormatting (msg) {	
// one-time formatting
//suppress notices, by hiding the  messages div
	if (set.HIDE_MESSAGE_AREA) {OBS_notices.style.display='none';} //?
	
	OBS_banner.style.display='table';
	document.getElementById('leftPane').style.width=set.LEFT_WIDTH;
	document.getElementById('rightPane').style.width=set.RIGHT_WIDTH;
	document.getElementById('centerPane').style.width=set.CENTER_WIDTH;
	document.getElementById('previewPane').style.width=set.PREVIEW_WIDTH;
	document.getElementById('programPane').style.width=set.PROGRAM_WIDTH;
	
	formatButton('menuButton', set.MENU_BUTTON);
	formatButton('tranButton', set.TRAN_BUTTON);
	formatButton('pushButton', set.PUSH_BUTTON);
	formatButton('programButton');
	formatButton('recordButton', (set.RECORD_BUTTON || set.GOLIVE_BUTTON));

	if (set.HIDE_SCENE_BOXES) {
		document.getElementById('previewBox').style.borderStyle='none';
		document.getElementById('programBox').style.borderStyle='none';
	}
	if (set.PANE_BORDERS) {
		let tags = document.getElementById('panes').children;
		for (let i = 0; i<tags.length; i++) {
			tags[i].style.borderColor=(set.PANE_BORDERS === true)?'white':set.PANE_BORDERS;
		}
	}
	if (set.PANE_BACKGROUND) {
		let tags = document.getElementById('panes').children;
		for (let i = 0; i<tags.length; i++) {
			tags[i].style.background=(set.PANE_BACKGROUND === true)?'black':set.PANE_BACKGROUND;
		}
	}
}

function formatButton(button, status ){
	//toggle button visibility with that of placeholder div 
	button=document.getElementById(button);
	sibling=button.parentNode.children[0];
	if (status) {
		button.style.display='inline-block';
		sibling.style.display='none';
	}
	else {
		button.disabled = true;
		button.style.display='none';
		sibling.style.display='initial';
	}
}

function doTransition() {
	if (OBS_inTransition) {return;}  // avoid while in transition
	if (OBS_previewScene === OBS_programScene) {return;}   //just in case
	let txt='TRAN: "'+OBS_previewScene+'"--&gt;"'+OBS_programScene+'"';
	if (set.SHOW_NOTICES) {showNotice (txt);}
	obsRequest ({'request-type':OBS_SetCurrentScene,'scene-name':OBS_previewScene});	
}

function doEndLive() { 
	let msg='About to end output stream: "'+ OBS_profile +'".\nAre you sure?';
	if (!confirm(msg)){return;}
	obsRequest(OBS_GetStreamingStatus,'endLive');
}

function doGoLive() {
	let txt='About to start streaming: "' +OBS_profile +'"\nAre you sure?';
	if (set.PREFERRED_PROFILE && (set.PREFERRED_PROFILE !== OBS_profile)) {
		txt='WARNING: Not Using Preferred Profile\n'+txt;
	}
	if (!confirm(txt)){return;}
	obsRequest(OBS_StartStreaming);
}

function doRecord() {
	let txt='About to start recording: "'+OBS_profile + '"\nAre you sure?';
	if (set.PREFERRED_PROFILE && (set.PREFERRED_PROFILE !== OBS_profile)) {
		txt='WARNING: Not Using Preferred Profile\n'+txt;
	}
	if (!confirm(txt)){return;}	
	obsRequest(OBS_StartRecording);
}

function beginProgramChange(msg) {
	if (showNotice) {showNotice('BegPC')};
	OBS_inTransition = true;
	OBS_pushButton.disabled = true;
	OBS_menuPushButton.disabled = true;
	OBS_tranButton.disabled = true;
	OBS_menuTranButton.disabled=true;
	OBS_tranBackground = OBS_tranButton.style.background;
	OBS_pushBackground = OBS_pushButton.style.background;
	OBS_tranButton.style.background='transparent';
	OBS_pushButton.style.background='transparent';
   //?this necessary because websockets bug: somgimes from-scene absent from msg
   let fromScene=msg['from-scene']?msg['from-scene']:OBS_programScene;
	if (set.PUSH_SCENE_TOGGLE)  {   
		if (msg['to-scene'] === OBS_pushScene) {  //this is a push
			setPushButtonScene(fromScene,'program')
		}
		else {
			setPushButtonScene(OBS_pushScene,'push scene');
		}
	}
 //? if (!msg['from-scene']) {  //?this test because of websockets bug: sometimes msg is missing from-scene
 //      alert('oops 2');
 //   }
	if (!OBS_studioMode) {  //mimic preview scene change when not in studio mode
      setPreviewLabel(fromScene,msg);
	}
}
function endProgramChange(msg) { 
	if (showNotice) {showNotice('EndPC')};
	if (OBS_pushedPreview && OBS_studioMode) {     //restore preview in case of a push
		obsRequest ({'request-type':OBS_SetPreviewScene,'scene-name':OBS_pushedPreview});	
		}
	setPushButtonScene(OBS_pushButtonScene);  	//reset button colors after preview/program changes
	OBS_tranButton.style.background=OBS_tranBackground;
	OBS_pushButton.style.background=OBS_pushBackground;
	OBS_inTransition = false;
	OBS_pushInProgress = false;
	OBS_pushedPreview = false;
}

function obsRequest(requestId, messageId) {
//issue JSON request passed as either an object or as a string request-type, from which
//a simple JSON request object is constructed
	let msg = {};
	if (typeof requestId === 'object') {
		Object.assign(msg,requestId);   //messageID takes precedence 
		msg['message-id']=messageId?messageId:(msg['messageId']?msg['messageId']:msg['request-type']);
	}
	else {
		msg['request-type']=requestId;
		msg['message-id']=messageId?messageId:requestId;
	}
	if (set.SHOW_REQUESTS) {showMessage(msg,'request');} 
	OBS_socket.send(JSON.stringify(msg));  	
}

function onMessage (e) {
	//high level websockets message handler
	let msg = JSON.parse (e.data);
	//soft errors 
	if (msg['error']==='requested scene does not exist') {
      if (OBS_pushInProgress) {
         doSetPush('Scene "'+OBS_pushInProgress+'" Does Not Exist');
      }
      return;
	}
	//hard errors
	if (typeof msg['error'] !== 'undefined') {
		showNotice (formatMessage(msg));
		if(askToStop (msg['error']))  {return;}
	}
	//no errors
 	if (typeof msg['update-type'] !== 'undefined') {
		handleEvent(msg)
		return;
	}
	if (typeof msg['message-id'] !== 'undefined') {
		handleRequest(msg);
		return;
	}
	showNotice(formatMessage(msg));
	let txt='Unexpected Websockets response';
   if(askToStop(txt)) {return;}   
}

function handleRequest(msg) {	
	//handle responses to explicit requests
	if (set.SHOW_REPLIES) {showMessage(msg),'reply';} 
	switch (msg['message-id']) {
		case OBS_SetCurrentScene:
		case OBS_SetPreviewScene:
		case OBS_StartRecording:
		case OBS_StartStreaming:
		case OBS_StopRecording:
		case OBS_StopStreaming:
		case OBS_TransitionToProgram:
			return;
		case 'obsInit1':  //getCurrentProfile
			OBS_profile = msg['profile-name'];	
			obsRequest(OBS_GetCurrentScene,'obsInit2');
			return;
		case 'obsInit2':   //getCurrentScene
			setProgramLabel(msg['name'],msg);
			obsRequest(OBS_GetStudioModeStatus,'obsInit3');
			return;
		case 'obsInit3':  //getStudioModeStatus
			applyStudioModeEffects(msg['studio-mode']); 
			if (OBS_studioMode) {
				obsRequest(OBS_GetPreviewScene,'obsInit4');
			}
			else {
				setPreviewLabel(OBS_programScene,msg);       //force, since not in studio mode 
				obsRequest(OBS_GetStreamingStatus,'obsInit5');
			}
			return;
		case 'obsInit4':  //getPreviewScene
			setPreviewLabel(msg['name'],msg);
			obsRequest(OBS_GetStreamingStatus,'obsInit5');
			return;
		case 'obsInit5':  //getStreaming Status
			obsReady(msg);
			return;
		case 'endLive':
			if (msg['recording']) {
				obsRequest (OBS_StopRecording);
			}
			if (msg['streaming']) {
				obsRequest (OBS_StopStreaming);
			}
			return;
		case OBS_GetSceneTransitionOverride:
			if (msg['transitionName'] ==='') {
				setActiveTransition(OBS_currentTransition,OBS_currentDuration);
			}
			else {
				setActiveTransition(msg['transitionName'],msg['transitionDuration']);
			}
			return;
		case OBS_GetStreamingStatus:
			applyStreamingEffects(msg);
			return;
		case OBS_GetCurrentProfile:
			OBS_profile = msg['profile-name'];
			return;
		case OBS_GetCurrentTransition:
			OBS_currentTransition=msg['name'];
			OBS_currentDuration=msg['duration'];
			obsRequest({'request-type':OBS_GetSceneTransitionOverride,'sceneName':OBS_previewScene}); 
			return;
		case 'obsSetProgram':
			setProgramLabel(msg['name'],msg);
			return;
		case 'obsSetPreview':
			setPreviewLabel(msg['name'],msg);
			return;
		case OBS_GetAuthRequired:
			if (msg['authRequired']) {
            if (!set.PASSWORD) {
               let txt='Websocket athentication is enabled without a Scene Banner password.';
               txt+='/nEnter a password to proceed';
               set.PASSWORD=prompt(txt);  
            }
				obsAuthenticate(msg);
			}
			else {
			//authentication not required, proceed with initialization
			obsRequest(OBS_GetCurrentProfile,'obsInit1');
			}
			return;
		case OBS_Authenticate:
			//authentication successful, proceed with initialization
			obsRequest(OBS_GetCurrentProfile,'obsInit1');
			return;
		default:
			showNotice(formatMessage(msg));
			askToStop ('Unexpected Websocket message-id "' + msg['message-id'] + '"');
	}
}

function handleEvent(msg) {	
	if (set.SHOW_EVENTS) {showMessage(msg,'event');} 		
	switch (msg['update-type'])  {
      //call out these uninteresting events early because they occur so often--performance 
		case 'MediaEnded':
		case 'TransitionVideoEnd':
			return; 	//do nothing
		case 'StudioModeSwitched':
         if (msg['new-state'] && OBS_previewScene ) {  //restore preview scene on return to studio mode if one present
             obsRequest({'request-type':OBS_SetPreviewScene,'scene-name':OBS_previewScene});
         }
         applyStudioModeEffects(msg['new-state']);
			return;
		case 'TransitionBegin':
			beginProgramChange (msg);  
			return;
		//TransitionEnd, SwitchScene, and PreviewSceneChanged occur in any order 
		//Thus take care with logic dependencies betwen 
		case 'TransitionEnd': 
			setProgramLabel(msg['to-scene'],msg); 
			endProgramChange(msg);
			return;
		case 'SwitchScenes':
			setProgramLabel(msg['scene-name'],msg); 
			endProgramChange(msg);
			return;
		case 'PreviewSceneChanged':  
			setPreviewLabel(msg['scene-name'],msg);
			return;
		case 'ScenesChanged':   //not a transition 
			obsRequest(OBS_GetCurrentScene,'obsSetProgram');  
			if (OBS_studioMode) {
				obsRequest(OBS_GetPreviewScene,'obsSetPreview');
			}
			return;
		case 'SwitchTransition':
		case 'TransitionDurationChanged':
			obsRequest(OBS_GetCurrentTransition);
			return;
		case 'ProfileChanged':
//		doRefresh();
//		return;
//?above provisional code forces a reload -- required because because
//successive profile changes sometimes do not fire this event			
			if (set.PREFERRED_PROFILE && (set.PREFERRED_PROFILE === OBS_profile)) {
					let txt ='WARNING: Preferred Profile has been dismissed';
					txt+= '\n   Now Using: "' + msg['profile'] + '"';
					txt+= '\n   Preferred:   "' + set.PREFERRED_PROFILE + '"';
					alert(txt);
				}
			OBS_profile = (msg['profile']);
			setStatusLabel(OBS_profile);		
			return;
		case 'StreamStarting':
		case 'RecordingStarting':
			setStatusLabel('Stream Starting...');
			return;
		case 'StreamStarted':
		case 'RecordingStarted':
			obsRequest(OBS_GetStreamingStatus);
			return;
		case 'StreamStopping':
		case 'RecordingStopping':
			setStatusLabel('Stream Quiescing...');
			return;
		case 'StreamStopped':
		case 'RecordingStopped':
			obsRequest(OBS_GetStreamingStatus);
			return;
		default:
			return;			//ignore uninteresting events
	}
}

function applyStreamingEffects(msg) {
	//adjust streaming indicator
	if (msg['streaming'] || msg['recording']) {
		document.getElementById('endliveTop').innerHTML='End';	
		document.getElementById('endliveBot').innerHTML=msg['streaming']?'Streaming':'Recording';
		document.getElementById('endliveButton').disabled = false;
		document.getElementById('goliveButton').disabled = true;
		document.getElementById('recordButton').disabled = true;
		document.getElementById('goliveButton').style.display='none';
		document.getElementById('recordButton').style.display='none';
		let button=document.getElementById('endliveButton');
		button.style.display=(set.GOLIVE_BUTTON || set.RECORD_BUTTON)?'inline-block':'none';
		button.style.background=msg['streaming']?'red':'orange';
			
	}
	else {
		document.getElementById('endliveButton').disabled = true;
		document.getElementById('goliveButton').disabled = false;
		document.getElementById('recordButton').disabled = false;
		document.getElementById('endliveButton').style.display='none';
		document.getElementById('goliveButton').style.display=set.GOLIVE_BUTTON?'inline-block':'none';
		document.getElementById('recordButton').style.display=set.RECORD_BUTTON?'inline-block':'none';
	}
	setStatusLabel(OBS_profile);
 }

function applyStudioModeEffects(studioModeStatus) {
	OBS_studioMode = studioModeStatus;
	if (studioModeStatus) {
		document.getElementById('previewPane').style.display='table-cell';
		document.getElementById('centerPane').style.display='table-cell';
		document.getElementById('programPane').style.display='table-cell';
		document.getElementById('spacer1').style.display='none';
		document.getElementById('spacer2').style.display='table-cell';
		document.getElementById('spacer3').style.display='table-cell';
		document.getElementById('spacer4').style.display='table-cell';
		document.getElementById('spacer5').style.display='table-cell';
		document.getElementById('spacer6').style.display='none';
		return;
	}
	
	//not in studio mode
	document.getElementById('spacer2').style.display='table-cell';
	document.getElementById('spacer3').style.display='none';
	document.getElementById('spacer4').style.display='none';
	document.getElementById('spacer5').style.display='table-cell';
	document.getElementById('previewPane').style.display='none';
	document.getElementById('programPane').style.display='table-cell';
	document.getElementById('spacer1').style.display='table-cell';
	document.getElementById('spacer6').style.display='table-cell';
	//center the program Pane by expanding the spacer6 to balance the 
	//pushButton in the centerPane
	if (set.PUSH_BUTTON) {
		document.getElementById('centerPane').style.display='table-cell';
		document.getElementById('spacer1').style.width='0px';
		document.getElementById('spacer6').style.width=set.CENTER_WIDTH;	
		
	}
	else {
		document.getElementById('centerPane').style.display='none';
		document.getElementById('spacer1').style.width='0px';
		document.getElementById('spacer6').style.width='0px';
	}
}

function setActiveTransition(transition, duration) {
	OBS_activeTransition=transition;
	let secs=(duration>0)?' ('+(duration/1000)+' sec)':'';
	document.getElementById('tranTop').innerHTML=transition+ secs;
	document.getElementById('menuTranButton').innerHTML=transition + '->' + OBS_previewScene;
}

function setPushButtonScene(name, source) {
//	if (!name) {     //?diagnostic, should never happen
//      let txt='No push button scene';
//		showNotice(txt); 
//		askToStop ('Cannot change Push Button to: "' + name + '"' , source);
//		return;
//	}

	OBS_pushButtonScene = name;
	document.getElementById('pushButtonAction').innerHTML = 'Push';
	document.getElementById('pushButtonScene').innerHTML = name?name:'<br>';
	document.getElementById('menuPushButton').innerHTML = 'Push->' + OBS_pushButtonScene;
	OBS_pushButton.disabled=false;      
	OBS_menuPushButton.disabled=false;
	OBS_menuPushButton.style.color=(OBS_pushButtonScene===OBS_programScene?'gray':'white');
	OBS_pushButton.style.color=(OBS_pushButtonScene===OBS_programScene?'gray':'initial');
}
function setProgramLabel(name, msg) {
//	if (!name) {     //?diagnostic, should never happen
//		showNotice(msg); 
//		askToStop ('Cannot change Program Scene to: "' + name + '"');		
//		return;
//	}
	OBS_programScene = name;
   document.getElementById('programBot').innerHTML = name?name:'<br>'
	OBS_tranButton.disabled=(OBS_previewScene===OBS_programScene?true:false);
	OBS_menuTranButton.disabled=(OBS_previewScene===OBS_programScene)?true:false;
	OBS_pushButton.disabled=false;
	OBS_pushButton.style.color=(OBS_pushButtonScene===OBS_programScene?'gray':'initial');
	OBS_menuPushButton.style.color=(OBS_pushButtonScene===OBS_programScene?'gray':'white');
OBS_tranTop.style.color=(OBS_tranButton.disabled?'white':'black');
}
function setPreviewLabel(name, msg) {
  OBS_previewScene=name;
  document.getElementById('previewBot').innerHTML = name?name:'<br>';
  document.getElementById('tranBot').innerHTML = name?name:'<br>';
	OBS_tranButton.disabled=(OBS_previewScene===OBS_programScene)?true:false;
	OBS_menuTranButton.disabled=(OBS_previewScene===OBS_programScene)?true:false;
	OBS_pushButton.disabled=false;
	OBS_menuPushButton.disabled=false;
OBS_tranTop.style.color=(OBS_tranButton.disabled?'white':'black');
	obsRequest(OBS_GetCurrentTransition);
}
function setStatusLabel(status) {
	document.getElementById('programTop').innerHTML = status?status:'<br>';
}

function formatMessage() {
	//iterate over all args, constructing message
	let txt='';
	for (let i = 0; i < arguments.length; i++) {
		txt+=(i?'<br>':'');
		txt+=(typeof arguments[i] === 'object'?JSON.stringify(arguments[i]):arguments[i]);
	}	
	return txt;
}

function showNotice(notice) {
	if (set.LOG_MESSAGES) {console.log (notice);}
	if (set.SHOW_AS_TICKER) {
		//notice=notice.replace(/[a-z]/g, '')
		OBS_notices.innerHTML= OBS_notices.innerHTML + '&nbsp;...<span>'+notice+'</span>';
		while (OBS_notices.scrollWidth > OBS_notices.offsetWidth ) {
				let pos=(OBS_notices.innerHTML.substr(6)).indexOf('&nbsp;');
				OBS_notices.innerHTML=OBS_notices.innerHTML.substr(pos+6);
		}
	return;
	}
	
	OBS_notices.innerHTML= notice + '<br>' + OBS_notices.innerHTML;
	// don't let notices area expand too much
	let lines=OBS_notices.innerHTML.split('<br>',OBS_messageLimit);			
	OBS_notices.innerHTML=lines.join('<br>');
}	
function showMessage(msg, source) {
	if (set.LOG_MESSAGES) {console.log (JSON.stringify(msg));}
	let txt ='';
	if (set.SHOW_AS_TICKER) {
	// abbreviate message to cap letters only, if enabled
		if (msg['request-type']) {
			txt='{'+msg['message-id'];
		} 
		else {
			txt+=msg['update-type']?msg['update-type']+',':'';
			txt+=msg['message-id']?'*'+msg['message-id']+'} ':'';
			txt+=msg['error']?'!'+msg['error']:'';
		}
		txt=txt.replace(/[a-z]/g, '');
		txt=(msg['update-type'] || msg['error'])?'<span>'+txt+'</span>':txt;
		OBS_notices.innerHTML += '&nbsp;'+txt;
		while (OBS_notices.scrollWidth > OBS_notices.offsetWidth ) {
				let pos=(OBS_notices.innerHTML.substr(6)).indexOf('&nbsp;');
				OBS_notices.innerHTML=OBS_notices.innerHTML.substr(pos+6);
		}		
		return;
	}

	// display messge with timestamp
	let d = new Date();
	let html=d.toLocaleTimeString();
	html=html.substr(0,html.search(' '));
	html='==>' + html +'.' + d.getMilliseconds() + '<br><br>';
	for (let item in msg) {
		if (typeof msg[item] === 'string') {
			html = (item + ': '+ msg[item]) + '<br>'  + html;
		}
	}
	OBS_notices.innerHTML =  html + OBS_notices.innerHTML;
	// don't let notices area expand too much
	let lines=OBS_notices.innerHTML.split('<br>',OBS_messageLimit);			
	OBS_notices.innerHTML=lines.join('<br>');
	return;
}

/* Serialize authentification request */
async function obsAuthenticate(msg){
	let auth = await hashPW( msg['salt'],msg['challenge'], set.PASSWORD);
	obsRequest({'request-type':OBS_Authenticate,'message-id':OBS_Authenticate,'auth':auth});	
	return;
}

/* Return an authenticahash (encoded binary SHA256) formatted for OBS Websockets  */
async function hashPW (salt, challenge, password) {
	return btoa( await binarySha256(btoa(await binarySha256(password+salt))+challenge));
	async function binarySha256(string) {
		const utf8 = new TextEncoder().encode(string);
		const msgBuffer = await crypto.subtle.digest('SHA-256', utf8);
		const msgArray = Array.from(new Uint8Array(msgBuffer));
		let str='';
		for (let i=0; i<msgArray.length; i++) {
			str+=String.fromCharCode(msgArray[i]);
		}
		return str;
	}
}